import streamlit as st
import os
import faiss
import numpy as np
from api_utils import load_api_data, create_embedding, create_client

# 質問に対する類似文書の最大取得数
TOP_K = 5

# Faissインデックスと埋め込みモデルの初期化
@st.cache_resource
def load_faiss_index(faiss_index_file):
    index = faiss.read_index(faiss_index_file)
    return index

@st.cache_resource
def load_embedding_model():
    api_data = load_api_data("api_embedding.json")
    embeddings = create_embedding(api_data)
    return embeddings

@st.cache_resource
def load_gpt_client():
    api_data = load_api_data("api_gpt41mini.json")
    client, model = create_client(api_data)
    return client, model

# ベクトル検索で類似文書のドキュメントを取得
def search_similar_docs(db, query_text, top_k=TOP_K):
    # FAISSのsimilarity_searchを使って類似ドキュメントを取得
    docs = db.similarity_search(query_text, k=top_k)
    return docs
# Streamlitアプリ本体
def main():
    st.title("RAGチャットアプリ")

    # Faissインデックスのパスをユーザーに入力させるUIを追加
    faiss_index_dir = st.text_input("Faissインデックスのディレクトリパスを入力してください。", value=os.path.abspath(os.path.join(os.path.dirname(__file__), './faiss1')))

    # セッションステートでチャット履歴管理
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    # 初期化
    # 入力されたパスのファイル存在チェック
    faiss_index_file = os.path.join(faiss_index_dir, "index.faiss")
    if not os.path.exists(faiss_index_file):
        st.error(f"指定されたFaissインデックスファイルが存在しません: {faiss_index_file}")
        return

    index = load_faiss_index(faiss_index_file)
    embeddings = load_embedding_model()
    client, model = load_gpt_client()

    # ユーザー入力
    user_input = st.text_input("質問を入力してください。", key="input")

    if st.button("送信") and user_input.strip():
        # FaissのDBをロード
        from langchain_community.vectorstores import FAISS
        faiss_db = FAISS.load_local(faiss_index_dir, embeddings=embeddings, allow_dangerous_deserialization=True)

        # 類似文書検索
        docs = search_similar_docs(faiss_db, user_input)

        # 類似文書のテキストとsourceを取得
        retrieved_docs = [doc.page_content for doc in docs]
        source_paths = [doc.metadata.get('source', '不明') for doc in docs]

        # GPTに渡すコンテキスト作成
        context_text = "\n".join(retrieved_docs)

        # GPTに質問とコンテキストを渡して回答生成
        prompt = f"以下の文書を参考に質問に答えてください。\n{context_text}\n質問: {user_input}\n回答:"

        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}]
        )
        answer = response.choices[0].message.content.strip()

        # チャット履歴に追加（参照文書のパスも含める）
        st.session_state.chat_history.append({
            "user": user_input,
            "bot": answer,
            "sources": source_paths
        })

        # 入力欄クリア（Streamlitの仕様上、直接session_state.inputを変更できないため代替処理）
        # st.experimental_rerun() は存在しないため代替案としてsession_stateのキーをリセット
        del st.session_state["input"]
    # チャット履歴表示をスクロール可能なコンテナに変更
    # スクロール可能なコンテナをst.markdownの外に出して囲む形に修正
    container_height = 300  # 高さをピクセルで指定（必要に応じて調整）
    scrollable_style = f"overflow-y: auto; height: {container_height}px; border: 1px solid #ddd; padding: 10px;"

    # Streamlitのst.markdownはdivタグの中で複数のマークダウンを正しくレンダリングしないため、
    # 回答ごとにdivタグで囲む形に修正し、HTMLの安全な埋め込みを使う方法に変更
    # チャット履歴表示を一つのHTML文字列にまとめてから出力
    chat_html_all = f'<div style="{scrollable_style}">'
    for chat in st.session_state.chat_history:
        chat_html_all += f"""
        <div style="margin-bottom: 10px;">
            <p><strong>質問:</strong> {chat['user']}</p>
            <p><strong>回答:</strong> {chat['bot']}</p>
        """
        if "sources" in chat:
            chat_html_all += "<p><strong>参照文書:</strong></p><ul>"
            for src in chat["sources"]:
                chat_html_all += f"<li>{src}</li>"
            chat_html_all += "</ul>"
        chat_html_all += "<hr></div>"
    chat_html_all += "</div>"
    st.markdown(chat_html_all, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
