import os
import warnings
import openpyxl
import pandas as pd
import streamlit as st
from pptx import Presentation  # pip install python-pptx

from langchain_community.document_loaders import Docx2txtLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain.document_loaders import DataFrameLoader
from langchain_community.document_loaders import PyPDFium2Loader, UnstructuredExcelLoader, TextLoader

from api_utils import load_api_data, create_embedding

# API接続情報の読み込み
api_data = load_api_data("api_embedding.json")

# AzureOpenAIクライアントとモデル名の作成
embeddings = create_embedding(api_data)

def list_files_by_extension(root_dir, extensions, output_file):
    """
    指定フォルダ以下のファイルを指定拡張子で絞り込み、
    絶対パスでリストアップしてファイルに保存する。

    Args:
        root_dir (str): 探索開始フォルダのパス（相対・絶対どちらも可）
        extensions (list): 対象とする拡張子のリスト（例: ['docx', 'pdf']）
        output_file (str): 結果を保存するファイルパス
    """
    matched_files = []
    extensions = set(ext.lower() for ext in extensions)

    for dirpath, dirnames, filenames in os.walk(root_dir):
        for filename in filenames:

            if filename.startswith('~'):  # ~から始まる一時ファイルは無視する
                continue

            if 'old' in dirpath.split(os.sep):  # oldフォルダ以下のファイルは無視する
                continue

            ext = filename.lower().split('.')[-1]  # 拡張子を取得
            if ext in extensions :                 # 拡張子が対象の場合、ﾘｽﾄｱｯﾌﾟする
                abs_path = os.path.abspath(os.path.join(dirpath, filename))
                matched_files.append(abs_path)

    with open(output_file, 'w', encoding='utf-8') as f:
        for file_path in matched_files:
            f.write(file_path + '\n')

    print(matched_files)
    print(f"処理完了: {len(matched_files)} 件のファイルパスを '{output_file}' に保存しました。")

def extract_text_from_docx_files(file_list_path: str, faiss_dir: str, progress_placeholder=None):
    """
    指定されたファイルリストに基づき、各ファイルのテキストを抽出し、
    チャンクに分割してFAISSインデックスを作成または更新し、保存します。

    Args:
        file_list_path (str): ファイルパスが1行ずつ記載されたテキストファイルのパス
        faiss_dir (str): FAISSインデックスの保存ディレクトリパス
        progress_placeholder: Streamlitのプレースホルダー（st.empty()）オブジェクト。進捗表示用。
    """

    # テキスト分割器を初期化（チャンクサイズ500、重複200）
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=200
    )

    list_all_docs = []

    # ファイルリストの総行数を取得
    with open(file_list_path, 'r', encoding='utf-8') as f:
        total_files = sum(1 for _ in f)

    # ファイルリストを1行ずつ読み込み処理
    count = 0
    with open(file_list_path, 'r', encoding='utf-8') as f:
        for line in f:
            count += 1
            file_path = line.strip()
            if progress_placeholder:
                progress_placeholder.text(f"処理中 {count}/{total_files} : {file_path}")
            else:
                print(f"処理中 {count}/{total_files} : {file_path}")
            if not file_path:
                continue
            _, ext = os.path.splitext(file_path)

            if ext.lower() == '.docx':
                # docxファイルの場合、Docx2txtLoaderでテキストを抽出して分割
                loader = Docx2txtLoader(file_path)
                texts = loader.load_and_split()

            elif ext.lower() in (".xlsx", ".xlsm"):
                # Excelファイルの場合、openpyxlでシートごとにテキストを抽出しDataFrameにまとめる
                wb = openpyxl.load_workbook(file_path)
                sheet_names = wb.sheetnames
                print(sheet_names)

                df_book_merge = pd.DataFrame()
                for sheet_name in sheet_names:
                    sheet = wb[sheet_name]

                    row_content_lst = []
                    for r, row_content in enumerate(sheet.iter_rows(values_only=True)):
                        row_text = ""
                        for cell_content in row_content:
                            if cell_content is not None:
                                row_text += str(cell_content) + ","
                        row_content_lst.append((r, row_text))

                    df_sheet = pd.DataFrame(row_content_lst, columns=["row", "content"])
                    df_sheet = df_sheet.query("content != ''")

                    df_sheet.insert(0, "source", file_path)
                    df_sheet.insert(1, "sheet", sheet_name)
                    df_book_merge = pd.concat([df_book_merge, df_sheet])

                loader = DataFrameLoader(df_book_merge, page_content_column="content")
                texts = loader.load_and_split()

            elif ext.lower() in (".xls"):
                # 古いExcel形式はUnstructuredExcelLoaderで処理
                loader = UnstructuredExcelLoader(file_path)
                texts = loader.load_and_split()

            elif ext.lower() in (".pptx"):
                # PPTXファイルの場合、python-pptxでスライド内のテキストを抽出
                tmp_presentation = Presentation(file_path)
                tmp_content_lst = []

                for idx, slide in enumerate(tmp_presentation.slides, start=0):
                    for shape in slide.shapes:
                        if hasattr(shape, "text"):
                            tmp_content_lst.append((idx, shape.text))

                tmp_content_df = pd.DataFrame(tmp_content_lst, columns=["page", "content"])

                # 修正: apply("") から apply("".join) に変更
                tmp_df_merge = tmp_content_df.groupby("page")["content"].apply("".join).reset_index()

                tmp_df_merge.insert(0, "source", file_path)

                loader = DataFrameLoader(tmp_df_merge, page_content_column="content")
                texts = loader.load_and_split()

            elif ext.lower() in (".pdf"):
                # PDFファイルはPyPDFium2Loaderで処理
                texts = []
                loader = PyPDFium2Loader(file_path)
                texts_tmp = loader.load_and_split()
                for page_idx in range(len(texts_tmp)):
                    if len(texts_tmp[page_idx].page_content) > 10:
                        texts.append(texts_tmp[page_idx])

            elif ext.lower() in (".txt"):
                # テキストファイルはエンコーディングを変えて読み込みを試みる
                try:
                    loader = TextLoader(file_path, encoding='utf-16')
                    texts = loader.load_and_split()
                except:
                    try:
                        loader = TextLoader(file_path, encoding='utf-8')
                        texts = loader.load_and_split()
                    except:
                        loader = TextLoader(file_path, encoding='cp932')
                        texts = loader.load_and_split()

            else:
                # 対応しない拡張子は無視
                continue

            docs = text_splitter.split_documents(texts)

            # docsの中身が無い場合はスキップ
            if len(docs) == 0:
                continue

            for doc in docs:
                list_all_docs.append([doc.metadata['source'], doc.page_content])

            if os.path.exists(faiss_dir + '/index.faiss'):
                faiss_db = FAISS.load_local(faiss_dir, embeddings=embeddings, allow_dangerous_deserialization=True)
                faiss_db.add_documents(docs)
            else:
                faiss_db = FAISS.from_documents(docs, embedding=embeddings)

            faiss_db.save_local(faiss_dir)

        df_all_docs = pd.DataFrame(list_all_docs, columns=["ファイルパス", "チャンク"])

        output_excel_path = "extracted_chunks.xlsx"
        df_all_docs.to_excel(output_excel_path, index=False)
        print(f"チャンクデータをExcelファイルに保存しました: {output_excel_path}")

        print(df_all_docs)

def print_faiss_data_count(faiss_dir: str, output_placeholder=None):
    """
    指定ディレクトリからFAISSインデックスをロードし、
    格納されているデータ件数をコンソールまたはStreamlit画面に表示する。

    Args:
        faiss_dir (str): FAISSインデックスの保存ディレクトリパス
        output_placeholder: Streamlitのプレースホルダー（st.empty()）オブジェクト。表示用。
    """
    # FAISSインデックスをロード（embeddingはキーワード引数で渡す必要あり）
    # allow_dangerous_deserialization=Trueでpickleの安全性警告を回避
    faiss_db = FAISS.load_local(faiss_dir, embeddings=embeddings, allow_dangerous_deserialization=True)
    # faiss_db.indexはfaiss.IndexFlatIPなどのインデックスオブジェクト
    # データ件数はindex.ntotalで取得可能
    count = faiss_db.index.ntotal
    message = f"FAISSに格納されているデータ件数: {count}"
    if output_placeholder:
        output_placeholder.text(message)
    else:
        print(message)

# def similarity_search(faiss_dir: str, question: str, output_placeholder=None):
#     """
#     指定ディレクトリのFAISSインデックスを使って類似検索を行い、
#     ヒットした上位5件のドキュメントの内容を表示する。

#     Args:
#         faiss_dir (str): FAISSインデックスの保存ディレクトリパス
#         question (str): 検索クエリの質問文
#         output_placeholder: Streamlitのプレースホルダー（st.empty()）オブジェクト。表示用。
#     """

#     # FAISSインデックスの読み込み
#     db = FAISS.load_local(folder_path=faiss_dir, embeddings=embeddings, allow_dangerous_deserialization=True)
#     if output_placeholder:
#         output_placeholder.text("Faiss index loaded")
#     else:
#         print("Faiss index loaded")

#     # 上位5件の類似ドキュメントを取得
#     searchDocs = db.similarity_search(question, k=5)
#     if searchDocs:
#         # 5件分の内容をまとめて表示（元ファイルパスも表示）
#         combined_text = ""
#         for i, doc in enumerate(searchDocs, start=1):
#             source = doc.metadata.get("source", "不明なファイルパス")
#             combined_text += (
#                 f"\n{'='*40}\n--- 類似ドキュメント {i} ---\n"
#                 f"元ファイルパス: {source}\n"
#                 f"{'='*40}\n{doc.page_content}\n\n"
#             )
#         if output_placeholder:
#             output_placeholder.text(combined_text)
#         else:
#             print(combined_text)
#     else:
#         if output_placeholder:
#             output_placeholder.text("類似ドキュメントが見つかりませんでした。")
#         else:
#             print("類似ドキュメントが見つかりませんでした。")

if __name__ == "__main__":
    # 警告を非表示に設定
    warnings.filterwarnings("ignore")

    st.title("ベクトルDB作成アプリ")

    # 対象フォルダの入力
    target_folder = st.text_input("対象フォルダのパスを入力してください", value="./doc")

    # 対象拡張子は固定
    target_extensions = ['docx', 'xlsx', 'xlsm', 'xls', 'pptx', 'pdf', 'txt']

    if st.button("ファイルリストアップ開始"):
        output_file = 'file_list.txt'
        list_files_by_extension(target_folder, target_extensions, output_file)
        st.success(f"処理完了: {output_file} にファイルリストを保存しました。")

        # 結果ファイルの内容を表示
        with open(output_file, 'r', encoding='utf-8') as f:
            file_list = f.read()
        html_content = '<div style="white-space: nowrap; overflow-x: auto; font-family: monospace; border: 1px solid #ddd; padding: 10px; height: 300px;">{}</div>'.format(file_list.replace("\n", "<br>"))
        st.markdown(html_content, unsafe_allow_html=True)

    # FAISSインデックス保存先の入力
    faiss_dir = st.text_input("FAISSインデックスの保存先フォルダパスを入力してください", value="./faiss1")

    if st.button("FAISSインデックス作成・更新開始"):
        with st.spinner("処理中...しばらくお待ちください。"):
            progress_placeholder = st.empty()
            extract_text_from_docx_files('file_list.txt', faiss_dir, progress_placeholder)
            print_faiss_data_count(faiss_dir, progress_placeholder)
        st.success("FAISSインデックス作成・更新が完了しました。")

    if st.button("FAISSインデックス削除"):
        try:
            faiss_index_path = os.path.join(faiss_dir, "index.faiss")
            faiss_pkl_path = os.path.join(faiss_dir, "index.pkl")
            deleted_files = []
            if os.path.exists(faiss_index_path):
                os.remove(faiss_index_path)
                deleted_files.append("index.faiss")
            if os.path.exists(faiss_pkl_path):
                os.remove(faiss_pkl_path)
                deleted_files.append("index.pkl")
            if deleted_files:
                st.success(f"削除しました: {', '.join(deleted_files)}")
            else:
                st.warning("削除対象のFAISSインデックスファイルが存在しません。")
        except Exception as e:
            st.error(f"削除中にエラーが発生しました: {e}")

    # question = st.text_input("質問を入力してください", value="")
    # if st.button("類似検索実行"):
    #     with st.spinner("検索中..."):
    #         output_placeholder = st.empty()
    #         similarity_search(faiss_dir, question, output_placeholder)
    #     st.success("類似検索が完了しました。")
